"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { MetricCard } from "@/components/dashboard/metric-card"
import { BarChartCard, LineChartCard } from "@/components/dashboard/charts"
import { DataTable } from "@/components/dashboard/data-table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dumbbell, Plus, Flame, Clock, Calendar, ChevronRight } from "lucide-react"
import { workouts, exerciseLogs, workoutChartData, getSummaryStats } from "@/lib/mock-data"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Field, FieldGroup, FieldLabel } from "@/components/ui/field"

const workoutTypes = ["Cardio", "Strength", "HIIT", "Yoga", "Running", "Swimming", "Cycling"]

export default function WorkoutsPage() {
  const stats = getSummaryStats()
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const getWorkoutColor = (type: string) => {
    const colors: Record<string, string> = {
      Cardio: "bg-chart-1/20 text-chart-1 border-chart-1/30",
      Strength: "bg-chart-2/20 text-chart-2 border-chart-2/30",
      HIIT: "bg-chart-5/20 text-chart-5 border-chart-5/30",
      Yoga: "bg-accent/20 text-accent border-accent/30",
      Running: "bg-chart-3/20 text-chart-3 border-chart-3/30",
      Swimming: "bg-primary/20 text-primary border-primary/30",
      Cycling: "bg-chart-4/20 text-chart-4 border-chart-4/30",
    }
    return colors[type] || "bg-secondary text-secondary-foreground"
  }

  const durationData = workoutChartData.map((d) => ({
    name: d.name,
    duration: d.duration,
  }))

  return (
    <DashboardLayout
      title="Workouts"
      subtitle="Track your fitness activities"
    >
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Dumbbell className="h-5 w-5 text-chart-3" />
          <span className="text-sm text-muted-foreground">
            {stats.workouts.sessionsThisWeek} workouts this week
          </span>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Log Workout
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Log Workout</DialogTitle>
              <DialogDescription>
                Record your exercise session
              </DialogDescription>
            </DialogHeader>
            <form
              onSubmit={(e) => {
                e.preventDefault()
                setIsDialogOpen(false)
              }}
              className="space-y-4"
            >
              <FieldGroup>
                <Field>
                  <FieldLabel>Workout Type</FieldLabel>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {workoutTypes.map((type) => (
                        <SelectItem key={type} value={type.toLowerCase()}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <div className="grid grid-cols-2 gap-4">
                  <Field>
                    <FieldLabel>Duration (minutes)</FieldLabel>
                    <Input type="number" placeholder="45" />
                  </Field>
                  <Field>
                    <FieldLabel>Calories Burned</FieldLabel>
                    <Input type="number" placeholder="350" />
                  </Field>
                </div>
              </FieldGroup>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Save Workout</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Weekly Calories"
          value={stats.workouts.weeklyCalories.toLocaleString()}
          unit="kcal"
          icon={Flame}
          variant="primary"
          change={12}
          changeLabel="from last week"
        />
        <MetricCard
          title="Active Minutes"
          value={stats.workouts.weeklyMinutes}
          unit="min"
          icon={Clock}
          change={8}
          changeLabel="from last week"
        />
        <MetricCard
          title="Sessions"
          value={stats.workouts.sessionsThisWeek}
          unit="this week"
          icon={Calendar}
        />
        <MetricCard
          title="Weekly Goal"
          value="5"
          unit="workouts"
          icon={Dumbbell}
        />
      </div>

      {/* Weekly Goal Progress */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-base font-medium">Weekly Workout Goal</CardTitle>
          <CardDescription>Target: 5 workout sessions per week</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">{stats.workouts.sessionsThisWeek} of 5 completed</span>
              <span className="font-medium">{Math.min(100, (stats.workouts.sessionsThisWeek / 5) * 100)}%</span>
            </div>
            <Progress value={Math.min(100, (stats.workouts.sessionsThisWeek / 5) * 100)} className="h-2" />
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <BarChartCard
          title="Calories Burned"
          description="Daily calorie expenditure"
          data={workoutChartData}
          bars={[
            { dataKey: "calories", color: "hsl(var(--chart-3))", name: "Calories" },
          ]}
        />
        <LineChartCard
          title="Workout Duration"
          description="Minutes per session"
          data={durationData}
          lines={[
            { dataKey: "duration", color: "hsl(var(--chart-1))", name: "Duration" },
          ]}
        />
      </div>

      {/* Workout Summary by Type */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-base font-medium">This Week by Workout Type</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {["Cardio", "Strength", "HIIT", "Yoga"].map((type) => {
              const typeWorkouts = workouts.filter((w) => w.workoutType === type)
              const totalCals = typeWorkouts.reduce((sum, w) => sum + (w.caloriesBurned || 0), 0)
              const totalMins = typeWorkouts.reduce((sum, w) => sum + w.durationMin, 0)
              return (
                <div
                  key={type}
                  className={`rounded-lg border p-4 ${getWorkoutColor(type)}`}
                >
                  <p className="text-sm font-medium">{type}</p>
                  <p className="mt-1 text-2xl font-bold">{typeWorkouts.length}</p>
                  <p className="text-xs opacity-80">
                    {totalMins} min · {Math.round(totalCals)} kcal
                  </p>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Recent Workouts */}
      <div className="mt-6">
        <DataTable
          title="Recent Workouts"
          description="Your workout history"
          data={workouts}
          columns={[
            {
              key: "recordedAt",
              header: "Date",
              render: (item) =>
                new Date(item.recordedAt).toLocaleDateString("en-US", {
                  weekday: "short",
                  month: "short",
                  day: "numeric",
                }),
            },
            {
              key: "workoutType",
              header: "Type",
              render: (item) => (
                <Badge className={getWorkoutColor(item.workoutType)}>
                  {item.workoutType}
                </Badge>
              ),
            },
            {
              key: "durationMin",
              header: "Duration",
              render: (item) => `${item.durationMin} min`,
            },
            {
              key: "caloriesBurned",
              header: "Calories",
              render: (item) => (
                <span className="font-medium">{item.caloriesBurned} kcal</span>
              ),
            },
            {
              key: "details",
              header: "",
              render: () => (
                <Button variant="ghost" size="sm">
                  <ChevronRight className="h-4 w-4" />
                </Button>
              ),
            },
          ]}
        />
      </div>

      {/* Recent Exercises */}
      <div className="mt-6">
        <DataTable
          title="Recent Exercises"
          description="Individual exercises from your workouts"
          data={exerciseLogs}
          columns={[
            {
              key: "exerciseName",
              header: "Exercise",
              render: (item) => (
                <span className="font-medium">{item.exerciseName}</span>
              ),
            },
            {
              key: "sets",
              header: "Sets",
              render: (item) => item.sets || "-",
            },
            {
              key: "reps",
              header: "Reps",
              render: (item) => item.reps || "-",
            },
            {
              key: "weightKg",
              header: "Weight",
              render: (item) =>
                item.weightKg ? `${item.weightKg} kg` : "Bodyweight",
            },
          ]}
        />
      </div>
    </DashboardLayout>
  )
}
