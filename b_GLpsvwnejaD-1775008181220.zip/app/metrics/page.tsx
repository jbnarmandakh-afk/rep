"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { MetricCard } from "@/components/dashboard/metric-card"
import { LineChartCard } from "@/components/dashboard/charts"
import { DataTable } from "@/components/dashboard/data-table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Activity, Plus, Scale, Percent, Heart, Ruler } from "lucide-react"
import { healthMetrics, weightChartData, user, getSummaryStats } from "@/lib/mock-data"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Field, FieldGroup, FieldLabel } from "@/components/ui/field"

const metricTypes = ["Weight", "Body Fat %", "BMI", "Resting Heart Rate", "Blood Glucose", "Steps"]

export default function MetricsPage() {
  const stats = getSummaryStats()
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const getBMICategory = (bmi: number) => {
    if (bmi < 18.5) return { label: "Underweight", color: "text-chart-3" }
    if (bmi < 25) return { label: "Normal", color: "text-accent" }
    if (bmi < 30) return { label: "Overweight", color: "text-chart-5" }
    return { label: "Obese", color: "text-destructive" }
  }

  const bmiCategory = getBMICategory(stats.metrics.bmi)

  return (
    <DashboardLayout
      title="Health Metrics"
      subtitle="Track your body measurements and vitals"
    >
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity className="h-5 w-5 text-primary" />
          <span className="text-sm text-muted-foreground">
            Last updated: {new Date(healthMetrics[0].recordedAt).toLocaleDateString()}
          </span>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Metric
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Log Metric</DialogTitle>
              <DialogDescription>
                Record a new health measurement
              </DialogDescription>
            </DialogHeader>
            <form
              onSubmit={(e) => {
                e.preventDefault()
                setIsDialogOpen(false)
              }}
              className="space-y-4"
            >
              <FieldGroup>
                <Field>
                  <FieldLabel>Metric Type</FieldLabel>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select metric" />
                    </SelectTrigger>
                    <SelectContent>
                      {metricTypes.map((type) => (
                        <SelectItem key={type} value={type.toLowerCase()}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <Field>
                  <FieldLabel>Value</FieldLabel>
                  <Input type="number" step="0.1" placeholder="Enter value" />
                </Field>
              </FieldGroup>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Save</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Body Stats Overview */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base font-medium">Body Overview</CardTitle>
          <CardDescription>Your current body measurements</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            <div className="text-center">
              <div className="mx-auto mb-2 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Scale className="h-8 w-8 text-primary" />
              </div>
              <p className="text-2xl font-bold">{stats.metrics.currentWeight} kg</p>
              <p className="text-sm text-muted-foreground">Current Weight</p>
            </div>
            <div className="text-center">
              <div className="mx-auto mb-2 flex h-16 w-16 items-center justify-center rounded-full bg-accent/10">
                <Ruler className="h-8 w-8 text-accent" />
              </div>
              <p className="text-2xl font-bold">{user.heightCm} cm</p>
              <p className="text-sm text-muted-foreground">Height</p>
            </div>
            <div className="text-center">
              <div className="mx-auto mb-2 flex h-16 w-16 items-center justify-center rounded-full bg-chart-3/10">
                <Percent className="h-8 w-8 text-chart-3" />
              </div>
              <p className="text-2xl font-bold">{stats.metrics.bodyFat}%</p>
              <p className="text-sm text-muted-foreground">Body Fat</p>
            </div>
            <div className="text-center">
              <div className="mx-auto mb-2 flex h-16 w-16 items-center justify-center rounded-full bg-chart-4/10">
                <Heart className="h-8 w-8 text-chart-4" />
              </div>
              <p className="text-2xl font-bold">{stats.metrics.restingHeartRate}</p>
              <p className="text-sm text-muted-foreground">Resting HR (bpm)</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Weight"
          value={stats.metrics.currentWeight}
          unit="kg"
          icon={Scale}
          variant="primary"
          change={-1.4}
          changeLabel="this month"
        />
        <MetricCard
          title="Body Fat"
          value={stats.metrics.bodyFat}
          unit="%"
          icon={Percent}
          change={-2}
          changeLabel="this month"
        />
        <MetricCard
          title="BMI"
          value={stats.metrics.bmi}
          icon={Activity}
        />
        <MetricCard
          title="Resting Heart Rate"
          value={stats.metrics.restingHeartRate}
          unit="bpm"
          icon={Heart}
          change={-3}
          changeLabel="improving"
        />
      </div>

      {/* BMI Status */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-base font-medium">BMI Analysis</CardTitle>
          <CardDescription>Body Mass Index classification</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <div className="mb-2 flex justify-between text-sm">
                <span className="text-muted-foreground">Your BMI: {stats.metrics.bmi}</span>
                <span className={`font-medium ${bmiCategory.color}`}>{bmiCategory.label}</span>
              </div>
              <div className="relative h-3 w-full overflow-hidden rounded-full bg-secondary">
                <div
                  className="absolute h-full bg-accent"
                  style={{ width: `${Math.min(100, (stats.metrics.bmi / 40) * 100)}%` }}
                />
                {/* Category markers */}
                <div className="absolute left-[46%] top-0 h-full w-0.5 bg-border" title="18.5" />
                <div className="absolute left-[62%] top-0 h-full w-0.5 bg-border" title="25" />
                <div className="absolute left-[75%] top-0 h-full w-0.5 bg-border" title="30" />
              </div>
              <div className="mt-1 flex justify-between text-xs text-muted-foreground">
                <span>Underweight</span>
                <span>Normal</span>
                <span>Overweight</span>
                <span>Obese</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Weight Chart */}
      <div className="mt-6">
        <LineChartCard
          title="Weight Trend"
          description="Your weight over the past month"
          data={weightChartData}
          lines={[
            { dataKey: "weight", color: "hsl(var(--chart-1))", name: "Weight (kg)" },
          ]}
        />
      </div>

      {/* Weight Goal */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-base font-medium">Weight Goal Progress</CardTitle>
          <CardDescription>Target: 68 kg</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Starting Weight</p>
                <p className="text-lg font-bold">72.0 kg</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Current</p>
                <p className="text-lg font-bold text-primary">{stats.metrics.currentWeight} kg</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Goal</p>
                <p className="text-lg font-bold text-accent">68.0 kg</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">1.5 kg lost</span>
                <span className="font-medium">37.5% to goal</span>
              </div>
              <Progress value={37.5} className="h-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Metrics History */}
      <div className="mt-6">
        <DataTable
          title="Measurement History"
          description="All your logged health metrics"
          data={healthMetrics}
          columns={[
            {
              key: "recordedAt",
              header: "Date",
              render: (item) =>
                new Date(item.recordedAt).toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                }),
            },
            {
              key: "metricType",
              header: "Metric",
              render: (item) => (
                <Badge variant="outline">{item.metricType}</Badge>
              ),
            },
            {
              key: "value",
              header: "Value",
              render: (item) => {
                const units: Record<string, string> = {
                  Weight: "kg",
                  "Body Fat %": "%",
                  BMI: "",
                  "Resting Heart Rate": "bpm",
                }
                return (
                  <span className="font-medium">
                    {item.value}
                    {units[item.metricType] && ` ${units[item.metricType]}`}
                  </span>
                )
              },
            },
          ]}
        />
      </div>
    </DashboardLayout>
  )
}
