"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { MetricCard } from "@/components/dashboard/metric-card"
import { AreaChartCard, BarChartCard } from "@/components/dashboard/charts"
import { DataTable } from "@/components/dashboard/data-table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Moon, Plus, Clock, Star, TrendingUp } from "lucide-react"
import { sleepLogs, sleepChartData, getSummaryStats } from "@/lib/mock-data"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Field, FieldGroup, FieldLabel } from "@/components/ui/field"

export default function SleepPage() {
  const stats = getSummaryStats()
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const getQualityLabel = (quality: number) => {
    if (quality >= 8) return { label: "Excellent", color: "text-accent" }
    if (quality >= 6) return { label: "Good", color: "text-chart-3" }
    if (quality >= 4) return { label: "Fair", color: "text-chart-5" }
    return { label: "Poor", color: "text-destructive" }
  }

  const sleepDurationData = sleepChartData.map((d) => ({
    name: d.name,
    hours: d.hours,
  }))

  const sleepQualityData = sleepChartData.map((d) => ({
    name: d.name,
    quality: d.quality,
  }))

  return (
    <DashboardLayout
      title="Sleep Tracking"
      subtitle="Monitor your sleep patterns and quality"
    >
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Moon className="h-5 w-5 text-accent" />
          <span className="text-sm text-muted-foreground">
            Last logged: {new Date(sleepLogs[0].sleepEnd).toLocaleDateString()}
          </span>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Log Sleep
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Log Sleep</DialogTitle>
              <DialogDescription>
                Enter your sleep details
              </DialogDescription>
            </DialogHeader>
            <form
              onSubmit={(e) => {
                e.preventDefault()
                setIsDialogOpen(false)
              }}
              className="space-y-4"
            >
              <FieldGroup>
                <div className="grid grid-cols-2 gap-4">
                  <Field>
                    <FieldLabel>Bedtime</FieldLabel>
                    <Input type="time" defaultValue="23:00" />
                  </Field>
                  <Field>
                    <FieldLabel>Wake Time</FieldLabel>
                    <Input type="time" defaultValue="07:00" />
                  </Field>
                </div>
                <Field>
                  <FieldLabel>Sleep Quality (1-10)</FieldLabel>
                  <Input type="number" min="1" max="10" placeholder="8" />
                </Field>
                <Field>
                  <FieldLabel>Notes (optional)</FieldLabel>
                  <Textarea placeholder="How did you feel?" />
                </Field>
              </FieldGroup>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Save</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Last Night"
          value={stats.sleep.lastNight}
          unit="hours"
          icon={Moon}
          variant="accent"
        />
        <MetricCard
          title="Sleep Quality"
          value={stats.sleep.quality}
          unit="/10"
          icon={Star}
          change={5}
          changeLabel="vs avg"
        />
        <MetricCard
          title="Weekly Average"
          value={stats.sleep.avgHours}
          unit="hours"
          icon={Clock}
          change={3}
          changeLabel="improving"
        />
        <MetricCard
          title="Sleep Goal"
          value="8"
          unit="hours"
          icon={TrendingUp}
        />
      </div>

      {/* Sleep Goal Progress */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-base font-medium">Weekly Sleep Goal Progress</CardTitle>
          <CardDescription>Target: 56 hours (8 hours × 7 days)</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">54.25 hours logged</span>
              <span className="font-medium">97%</span>
            </div>
            <Progress value={97} className="h-2" />
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <AreaChartCard
          title="Sleep Duration"
          description="Hours of sleep per night"
          data={sleepDurationData}
          areas={[
            { dataKey: "hours", color: "hsl(var(--chart-2))", name: "Hours" },
          ]}
        />
        <BarChartCard
          title="Sleep Quality Score"
          description="Quality rating per night (1-10)"
          data={sleepQualityData}
          bars={[
            { dataKey: "quality", color: "hsl(var(--chart-1))", name: "Quality" },
          ]}
        />
      </div>

      {/* Sleep Tips */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-base font-medium">Sleep Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="rounded-lg border border-border bg-secondary/30 p-4">
              <p className="text-sm font-medium">Best Sleep Day</p>
              <p className="mt-1 text-2xl font-bold text-accent">Friday</p>
              <p className="text-xs text-muted-foreground">9/10 quality avg</p>
            </div>
            <div className="rounded-lg border border-border bg-secondary/30 p-4">
              <p className="text-sm font-medium">Optimal Bedtime</p>
              <p className="mt-1 text-2xl font-bold text-primary">11:00 PM</p>
              <p className="text-xs text-muted-foreground">Based on your data</p>
            </div>
            <div className="rounded-lg border border-border bg-secondary/30 p-4">
              <p className="text-sm font-medium">Sleep Consistency</p>
              <p className="mt-1 text-2xl font-bold text-chart-3">85%</p>
              <p className="text-xs text-muted-foreground">Great routine!</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* History Table */}
      <div className="mt-6">
        <DataTable
          title="Sleep History"
          description="Your sleep log entries"
          data={sleepLogs.map((log) => {
            const start = new Date(log.sleepStart)
            const end = new Date(log.sleepEnd)
            const hours = (end.getTime() - start.getTime()) / (1000 * 60 * 60)
            return { ...log, hours: Math.round(hours * 10) / 10 }
          })}
          columns={[
            {
              key: "sleepEnd",
              header: "Date",
              render: (item) =>
                new Date(item.sleepEnd).toLocaleDateString("en-US", {
                  weekday: "short",
                  month: "short",
                  day: "numeric",
                }),
            },
            {
              key: "times",
              header: "Bedtime → Wake",
              render: (item) => {
                const start = new Date(item.sleepStart)
                const end = new Date(item.sleepEnd)
                return `${start.toLocaleTimeString("en-US", {
                  hour: "numeric",
                  minute: "2-digit",
                })} → ${end.toLocaleTimeString("en-US", {
                  hour: "numeric",
                  minute: "2-digit",
                })}`
              },
            },
            {
              key: "hours",
              header: "Duration",
              render: (item) => <span className="font-medium">{item.hours}h</span>,
            },
            {
              key: "sleepQuality",
              header: "Quality",
              render: (item) => {
                const quality = getQualityLabel(item.sleepQuality)
                return (
                  <div className="flex items-center gap-2">
                    <span className={`font-medium ${quality.color}`}>
                      {item.sleepQuality}/10
                    </span>
                    <Badge variant="outline" className="text-xs">
                      {quality.label}
                    </Badge>
                  </div>
                )
              },
            },
            {
              key: "notes",
              header: "Notes",
              render: (item) => (
                <span className="text-muted-foreground">{item.notes || "-"}</span>
              ),
            },
          ]}
        />
      </div>
    </DashboardLayout>
  )
}
