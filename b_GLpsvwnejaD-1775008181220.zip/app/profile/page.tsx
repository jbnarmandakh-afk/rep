"use client"

import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { User, Mail, Calendar, Ruler, Scale } from "lucide-react"
import { user } from "@/lib/mock-data"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Field, FieldGroup, FieldLabel } from "@/components/ui/field"

export default function ProfilePage() {
  const memberSince = new Date(user.createdAt).toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  })

  return (
    <DashboardLayout
      title="Profile"
      subtitle="Manage your account settings"
    >
      {/* Profile Header */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center gap-4 sm:flex-row">
            <Avatar className="h-20 w-20">
              <AvatarFallback className="bg-primary text-primary-foreground text-2xl">
                {user.name.split(" ").map((n) => n[0]).join("")}
              </AvatarFallback>
            </Avatar>
            <div className="text-center sm:text-left">
              <h2 className="text-xl font-semibold">{user.name}</h2>
              <p className="text-sm text-muted-foreground">{user.email}</p>
              <div className="mt-2 flex flex-wrap justify-center gap-2 sm:justify-start">
                <Badge variant="secondary">Member since {memberSince}</Badge>
                <Badge variant="outline" className="border-accent text-accent">
                  Active
                </Badge>
              </div>
            </div>
            <div className="sm:ml-auto">
              <Button variant="outline">Edit Photo</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <User className="h-4 w-4" />
              Personal Information
            </CardTitle>
            <CardDescription>Update your personal details</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4">
              <FieldGroup>
                <Field>
                  <FieldLabel>Full Name</FieldLabel>
                  <Input defaultValue={user.name} />
                </Field>
                <Field>
                  <FieldLabel>Email</FieldLabel>
                  <Input type="email" defaultValue={user.email} />
                </Field>
                <Field>
                  <FieldLabel>Date of Birth</FieldLabel>
                  <Input type="date" defaultValue={user.dateOfBirth} />
                </Field>
                <Field>
                  <FieldLabel>Gender</FieldLabel>
                  <Select defaultValue={user.gender?.toLowerCase()}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                      <SelectItem value="prefer-not">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
              </FieldGroup>
              <Button type="button">Save Changes</Button>
            </form>
          </CardContent>
        </Card>

        {/* Body Measurements */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <Ruler className="h-4 w-4" />
              Body Measurements
            </CardTitle>
            <CardDescription>Your baseline measurements</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4">
              <FieldGroup>
                <div className="grid grid-cols-2 gap-4">
                  <Field>
                    <FieldLabel>Height (cm)</FieldLabel>
                    <Input type="number" step="0.1" defaultValue={user.heightCm} />
                  </Field>
                  <Field>
                    <FieldLabel>Weight (kg)</FieldLabel>
                    <Input type="number" step="0.1" defaultValue={user.weightKg} />
                  </Field>
                </div>
              </FieldGroup>
              <div className="rounded-lg border border-border bg-secondary/30 p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Calculated BMI</p>
                    <p className="text-xs text-muted-foreground">Based on your height and weight</p>
                  </div>
                  <p className="text-2xl font-bold text-primary">
                    {(user.weightKg / Math.pow(user.heightCm / 100, 2)).toFixed(1)}
                  </p>
                </div>
              </div>
              <Button type="button">Update Measurements</Button>
            </form>
          </CardContent>
        </Card>

        {/* Health Goals */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <Scale className="h-4 w-4" />
              Health Goals
            </CardTitle>
            <CardDescription>Set your target goals</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4">
              <FieldGroup>
                <Field>
                  <FieldLabel>Target Weight (kg)</FieldLabel>
                  <Input type="number" step="0.1" defaultValue="68" />
                </Field>
                <Field>
                  <FieldLabel>Weekly Workout Goal</FieldLabel>
                  <Select defaultValue="5">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3">3 sessions/week</SelectItem>
                      <SelectItem value="4">4 sessions/week</SelectItem>
                      <SelectItem value="5">5 sessions/week</SelectItem>
                      <SelectItem value="6">6 sessions/week</SelectItem>
                      <SelectItem value="7">7 sessions/week</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Field>
                  <FieldLabel>Daily Sleep Goal (hours)</FieldLabel>
                  <Select defaultValue="8">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="6">6 hours</SelectItem>
                      <SelectItem value="7">7 hours</SelectItem>
                      <SelectItem value="8">8 hours</SelectItem>
                      <SelectItem value="9">9 hours</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
              </FieldGroup>
              <Button type="button">Save Goals</Button>
            </form>
          </CardContent>
        </Card>

        {/* Account */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <Mail className="h-4 w-4" />
              Account Settings
            </CardTitle>
            <CardDescription>Manage your account</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-lg border border-border p-4">
              <div>
                <p className="font-medium">Email Notifications</p>
                <p className="text-sm text-muted-foreground">Receive weekly health summaries</p>
              </div>
              <Button variant="outline" size="sm">Configure</Button>
            </div>
            <div className="flex items-center justify-between rounded-lg border border-border p-4">
              <div>
                <p className="font-medium">Export Data</p>
                <p className="text-sm text-muted-foreground">Download all your health data</p>
              </div>
              <Button variant="outline" size="sm">Export</Button>
            </div>
            <div className="flex items-center justify-between rounded-lg border border-destructive/30 bg-destructive/5 p-4">
              <div>
                <p className="font-medium text-destructive">Delete Account</p>
                <p className="text-sm text-muted-foreground">Permanently delete your account</p>
              </div>
              <Button variant="destructive" size="sm">Delete</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
