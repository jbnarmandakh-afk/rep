"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { MetricCard } from "@/components/dashboard/metric-card"
import { LineChartCard } from "@/components/dashboard/charts"
import { DataTable } from "@/components/dashboard/data-table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Heart, Plus, Activity, TrendingDown } from "lucide-react"
import { bloodPressureLogs, bloodPressureChartData, getSummaryStats } from "@/lib/mock-data"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Field, FieldGroup, FieldLabel } from "@/components/ui/field"

export default function BloodPressurePage() {
  const stats = getSummaryStats()
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const getBPStatus = (systolic: number, diastolic: number) => {
    if (systolic < 120 && diastolic < 80) return { label: "Normal", variant: "default" as const }
    if (systolic < 130 && diastolic < 80) return { label: "Elevated", variant: "secondary" as const }
    if (systolic < 140 || diastolic < 90) return { label: "High Stage 1", variant: "destructive" as const }
    return { label: "High Stage 2", variant: "destructive" as const }
  }

  return (
    <DashboardLayout
      title="Blood Pressure"
      subtitle="Track and monitor your blood pressure readings"
    >
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Heart className="h-5 w-5 text-primary" />
          <span className="text-sm text-muted-foreground">
            Last reading: {new Date(bloodPressureLogs[0].recordedAt).toLocaleDateString()}
          </span>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Reading
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Log Blood Pressure</DialogTitle>
              <DialogDescription>
                Enter your blood pressure reading
              </DialogDescription>
            </DialogHeader>
            <form
              onSubmit={(e) => {
                e.preventDefault()
                setIsDialogOpen(false)
              }}
              className="space-y-4"
            >
              <FieldGroup>
                <div className="grid grid-cols-2 gap-4">
                  <Field>
                    <FieldLabel>Systolic (upper)</FieldLabel>
                    <Input type="number" placeholder="120" />
                  </Field>
                  <Field>
                    <FieldLabel>Diastolic (lower)</FieldLabel>
                    <Input type="number" placeholder="80" />
                  </Field>
                </div>
                <Field>
                  <FieldLabel>Heart Rate (optional)</FieldLabel>
                  <Input type="number" placeholder="72" />
                </Field>
                <Field>
                  <FieldLabel>Notes (optional)</FieldLabel>
                  <Textarea placeholder="Any relevant notes..." />
                </Field>
              </FieldGroup>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Save Reading</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Current Reading"
          value={`${stats.bloodPressure.systolic}/${stats.bloodPressure.diastolic}`}
          unit="mmHg"
          icon={Heart}
          variant="primary"
        />
        <MetricCard
          title="Heart Rate"
          value={stats.bloodPressure.heartRate}
          unit="bpm"
          icon={Activity}
          change={-2}
          changeLabel="vs yesterday"
        />
        <MetricCard
          title="7-Day Average"
          value="120/80"
          unit="mmHg"
          icon={TrendingDown}
          change={-1}
          changeLabel="improving"
        />
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Badge variant="default" className="bg-accent text-accent-foreground">
                Normal
              </Badge>
              <span className="text-sm text-muted-foreground">
                Within healthy range
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Chart */}
      <div className="mt-6">
        <LineChartCard
          title="Blood Pressure Trend"
          description="Systolic and diastolic readings over the past 7 days"
          data={bloodPressureChartData}
          lines={[
            { dataKey: "systolic", color: "hsl(var(--chart-1))", name: "Systolic" },
            { dataKey: "diastolic", color: "hsl(var(--chart-2))", name: "Diastolic" },
          ]}
        />
      </div>

      {/* Reference Ranges */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-base font-medium">Blood Pressure Categories</CardTitle>
          <CardDescription>Reference ranges from the American Heart Association</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-lg border border-accent/30 bg-accent/10 p-3">
              <p className="text-sm font-medium text-accent">Normal</p>
              <p className="text-xs text-muted-foreground">{"< 120/80 mmHg"}</p>
            </div>
            <div className="rounded-lg border border-chart-3/30 bg-chart-3/10 p-3">
              <p className="text-sm font-medium text-chart-3">Elevated</p>
              <p className="text-xs text-muted-foreground">120-129/{"<"}80 mmHg</p>
            </div>
            <div className="rounded-lg border border-chart-5/30 bg-chart-5/10 p-3">
              <p className="text-sm font-medium text-chart-5">High Stage 1</p>
              <p className="text-xs text-muted-foreground">130-139/80-89 mmHg</p>
            </div>
            <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-3">
              <p className="text-sm font-medium text-destructive">High Stage 2</p>
              <p className="text-xs text-muted-foreground">≥140/90 mmHg</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* History Table */}
      <div className="mt-6">
        <DataTable
          title="Reading History"
          description="All your blood pressure measurements"
          data={bloodPressureLogs}
          columns={[
            {
              key: "recordedAt",
              header: "Date & Time",
              render: (item) =>
                new Date(item.recordedAt).toLocaleString("en-US", {
                  month: "short",
                  day: "numeric",
                  hour: "numeric",
                  minute: "2-digit",
                }),
            },
            {
              key: "bp",
              header: "Blood Pressure",
              render: (item) => (
                <span className="font-medium">
                  {item.systolic}/{item.diastolic} mmHg
                </span>
              ),
            },
            {
              key: "heartRate",
              header: "Heart Rate",
              render: (item) => `${item.heartRate} bpm`,
            },
            {
              key: "status",
              header: "Status",
              render: (item) => {
                const status = getBPStatus(item.systolic, item.diastolic)
                return <Badge variant={status.variant}>{status.label}</Badge>
              },
            },
            {
              key: "notes",
              header: "Notes",
              render: (item) => (
                <span className="text-muted-foreground">{item.notes || "-"}</span>
              ),
            },
          ]}
        />
      </div>
    </DashboardLayout>
  )
}
