"use client"

import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { MetricCard } from "@/components/dashboard/metric-card"
import { LineChartCard, BarChartCard, AreaChartCard } from "@/components/dashboard/charts"
import { DataTable } from "@/components/dashboard/data-table"
import { Heart, Moon, Dumbbell, Scale, Activity, Zap } from "lucide-react"
import {
  getSummaryStats,
  bloodPressureChartData,
  sleepChartData,
  workoutChartData,
  workouts,
  bloodPressureLogs,
} from "@/lib/mock-data"
import { Badge } from "@/components/ui/badge"

export default function DashboardPage() {
  const stats = getSummaryStats()

  const recentWorkouts = workouts.slice(0, 5)
  const recentBPReadings = bloodPressureLogs.slice(0, 5)

  return (
    <DashboardLayout
      title="Dashboard"
      subtitle="Your health at a glance"
    >
      {/* Quick Stats Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Blood Pressure"
          value={`${stats.bloodPressure.systolic}/${stats.bloodPressure.diastolic}`}
          unit="mmHg"
          icon={Heart}
          variant="primary"
          change={-2}
          changeLabel="from last week"
        />
        <MetricCard
          title="Sleep Last Night"
          value={stats.sleep.lastNight}
          unit="hours"
          icon={Moon}
          variant="accent"
          change={5}
          changeLabel="vs avg"
        />
        <MetricCard
          title="Weekly Calories"
          value={stats.workouts.weeklyCalories.toLocaleString()}
          unit="kcal"
          icon={Zap}
          change={12}
          changeLabel="from last week"
        />
        <MetricCard
          title="Current Weight"
          value={stats.metrics.currentWeight}
          unit="kg"
          icon={Scale}
          change={-1.4}
          changeLabel="this month"
        />
      </div>

      {/* Charts Section */}
      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <LineChartCard
          title="Blood Pressure Trend"
          description="Last 7 days"
          data={bloodPressureChartData}
          lines={[
            { dataKey: "systolic", color: "hsl(var(--chart-1))", name: "Systolic" },
            { dataKey: "diastolic", color: "hsl(var(--chart-2))", name: "Diastolic" },
          ]}
        />
        <AreaChartCard
          title="Sleep Quality"
          description="Hours & quality score"
          data={sleepChartData}
          areas={[
            { dataKey: "hours", color: "hsl(var(--chart-2))", name: "Hours" },
          ]}
        />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <BarChartCard
          title="Workout Activity"
          description="Calories burned per day"
          data={workoutChartData}
          bars={[
            { dataKey: "calories", color: "hsl(var(--chart-3))", name: "Calories" },
          ]}
        />
        <div className="grid gap-4 sm:grid-cols-2">
          <MetricCard
            title="Resting Heart Rate"
            value={stats.metrics.restingHeartRate}
            unit="bpm"
            icon={Activity}
            change={-3}
            changeLabel="improving"
          />
          <MetricCard
            title="BMI"
            value={stats.metrics.bmi}
            icon={Scale}
          />
          <MetricCard
            title="Body Fat"
            value={stats.metrics.bodyFat}
            unit="%"
            change={-2}
            changeLabel="this month"
          />
          <MetricCard
            title="Active Minutes"
            value={stats.workouts.weeklyMinutes}
            unit="min/week"
            icon={Dumbbell}
            change={8}
            changeLabel="from last week"
          />
        </div>
      </div>

      {/* Recent Activity Tables */}
      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <DataTable
          title="Recent Workouts"
          description="Your latest exercise sessions"
          data={recentWorkouts}
          columns={[
            {
              key: "workoutType",
              header: "Type",
              render: (item) => (
                <Badge variant="secondary" className="font-normal">
                  {item.workoutType}
                </Badge>
              ),
            },
            { key: "durationMin", header: "Duration", render: (item) => `${item.durationMin} min` },
            { key: "caloriesBurned", header: "Calories", render: (item) => `${item.caloriesBurned} kcal` },
            {
              key: "recordedAt",
              header: "Date",
              render: (item) =>
                new Date(item.recordedAt).toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                }),
            },
          ]}
        />
        <DataTable
          title="Blood Pressure History"
          description="Recent readings"
          data={recentBPReadings}
          columns={[
            {
              key: "bp",
              header: "BP",
              render: (item) => (
                <span className="font-medium">
                  {item.systolic}/{item.diastolic}
                </span>
              ),
            },
            { key: "heartRate", header: "Heart Rate", render: (item) => `${item.heartRate} bpm` },
            {
              key: "recordedAt",
              header: "Date",
              render: (item) =>
                new Date(item.recordedAt).toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                }),
            },
            {
              key: "notes",
              header: "Notes",
              render: (item) => (
                <span className="text-muted-foreground">{item.notes || "-"}</span>
              ),
            },
          ]}
        />
      </div>
    </DashboardLayout>
  )
}
