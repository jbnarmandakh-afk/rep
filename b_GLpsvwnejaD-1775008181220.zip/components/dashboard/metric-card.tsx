"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { TrendingUp, TrendingDown, Minus, type LucideIcon } from "lucide-react"

interface MetricCardProps {
  title: string
  value: string | number
  unit?: string
  change?: number
  changeLabel?: string
  icon?: LucideIcon
  className?: string
  variant?: "default" | "primary" | "accent"
}

export function MetricCard({
  title,
  value,
  unit,
  change,
  changeLabel,
  icon: Icon,
  className,
  variant = "default",
}: MetricCardProps) {
  const getTrend = () => {
    if (change === undefined) return null
    if (change > 0) return { icon: TrendingUp, color: "text-accent", label: `+${change}%` }
    if (change < 0) return { icon: TrendingDown, color: "text-destructive", label: `${change}%` }
    return { icon: Minus, color: "text-muted-foreground", label: "0%" }
  }

  const trend = getTrend()

  return (
    <Card
      className={cn(
        "relative overflow-hidden",
        variant === "primary" && "border-primary/20 bg-primary/5",
        variant === "accent" && "border-accent/20 bg-accent/5",
        className
      )}
    >
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        {Icon && (
          <Icon
            className={cn(
              "h-4 w-4",
              variant === "primary" && "text-primary",
              variant === "accent" && "text-accent",
              variant === "default" && "text-muted-foreground"
            )}
          />
        )}
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline gap-1">
          <span className="text-2xl font-bold text-foreground">{value}</span>
          {unit && <span className="text-sm text-muted-foreground">{unit}</span>}
        </div>
        {trend && (
          <div className="mt-2 flex items-center gap-1 text-xs">
            <trend.icon className={cn("h-3 w-3", trend.color)} />
            <span className={trend.color}>{trend.label}</span>
            {changeLabel && (
              <span className="text-muted-foreground">{changeLabel}</span>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
