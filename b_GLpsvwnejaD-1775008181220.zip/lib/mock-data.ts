// Mock data for health tracking dashboard
// In production, this would come from your backend API

export const user = {
  id: 1,
  name: "John Doe",
  email: "john@email.com",
  dateOfBirth: "2000-05-21",
  gender: "Male",
  heightCm: 175.5,
  weightKg: 70.2,
  createdAt: "2026-04-01T10:00:00",
}

export const bloodPressureLogs = [
  { id: 101, systolic: 120, diastolic: 80, heartRate: 72, recordedAt: "2026-04-01T09:00:00", notes: "Post workout reading" },
  { id: 102, systolic: 118, diastolic: 78, heartRate: 68, recordedAt: "2026-03-31T09:00:00", notes: "Morning reading" },
  { id: 103, systolic: 122, diastolic: 82, heartRate: 74, recordedAt: "2026-03-30T09:00:00", notes: "" },
  { id: 104, systolic: 119, diastolic: 79, heartRate: 70, recordedAt: "2026-03-29T09:00:00", notes: "Rested" },
  { id: 105, systolic: 124, diastolic: 84, heartRate: 76, recordedAt: "2026-03-28T09:00:00", notes: "After coffee" },
  { id: 106, systolic: 116, diastolic: 76, heartRate: 66, recordedAt: "2026-03-27T09:00:00", notes: "" },
  { id: 107, systolic: 121, diastolic: 81, heartRate: 72, recordedAt: "2026-03-26T09:00:00", notes: "" },
]

export const bloodPressureChartData = [
  { name: "Mar 26", systolic: 121, diastolic: 81 },
  { name: "Mar 27", systolic: 116, diastolic: 76 },
  { name: "Mar 28", systolic: 124, diastolic: 84 },
  { name: "Mar 29", systolic: 119, diastolic: 79 },
  { name: "Mar 30", systolic: 122, diastolic: 82 },
  { name: "Mar 31", systolic: 118, diastolic: 78 },
  { name: "Apr 01", systolic: 120, diastolic: 80 },
]

export const workouts = [
  { id: 201, workoutType: "Cardio", durationMin: 45, caloriesBurned: 350.5, recordedAt: "2026-04-01T07:00:00" },
  { id: 202, workoutType: "Strength", durationMin: 60, caloriesBurned: 280, recordedAt: "2026-03-31T07:00:00" },
  { id: 203, workoutType: "HIIT", durationMin: 30, caloriesBurned: 400, recordedAt: "2026-03-30T07:00:00" },
  { id: 204, workoutType: "Yoga", durationMin: 45, caloriesBurned: 150, recordedAt: "2026-03-29T08:00:00" },
  { id: 205, workoutType: "Cardio", durationMin: 40, caloriesBurned: 320, recordedAt: "2026-03-28T07:00:00" },
  { id: 206, workoutType: "Strength", durationMin: 55, caloriesBurned: 260, recordedAt: "2026-03-27T07:00:00" },
  { id: 207, workoutType: "Running", durationMin: 35, caloriesBurned: 380, recordedAt: "2026-03-26T06:30:00" },
]

export const exerciseLogs = [
  { id: 301, workoutId: 202, exerciseName: "Bench Press", sets: 4, reps: 10, weightKg: 60 },
  { id: 302, workoutId: 202, exerciseName: "Squats", sets: 4, reps: 12, weightKg: 80 },
  { id: 303, workoutId: 202, exerciseName: "Deadlift", sets: 3, reps: 8, weightKg: 100 },
  { id: 304, workoutId: 202, exerciseName: "Shoulder Press", sets: 3, reps: 10, weightKg: 40 },
  { id: 305, workoutId: 206, exerciseName: "Pull Ups", sets: 4, reps: 8, weightKg: 0 },
  { id: 306, workoutId: 206, exerciseName: "Bicep Curls", sets: 3, reps: 12, weightKg: 15 },
]

export const workoutChartData = [
  { name: "Mon", calories: 380, duration: 35 },
  { name: "Tue", calories: 260, duration: 55 },
  { name: "Wed", calories: 320, duration: 40 },
  { name: "Thu", calories: 150, duration: 45 },
  { name: "Fri", calories: 400, duration: 30 },
  { name: "Sat", calories: 280, duration: 60 },
  { name: "Sun", calories: 350, duration: 45 },
]

export const sleepLogs = [
  { id: 401, sleepStart: "2026-03-31T23:00:00", sleepEnd: "2026-04-01T07:00:00", sleepQuality: 8, notes: "Felt rested" },
  { id: 402, sleepStart: "2026-03-30T23:30:00", sleepEnd: "2026-03-31T06:30:00", sleepQuality: 7, notes: "" },
  { id: 403, sleepStart: "2026-03-29T22:45:00", sleepEnd: "2026-03-30T06:45:00", sleepQuality: 8, notes: "Great sleep" },
  { id: 404, sleepStart: "2026-03-28T00:00:00", sleepEnd: "2026-03-29T07:30:00", sleepQuality: 6, notes: "Woke up once" },
  { id: 405, sleepStart: "2026-03-27T23:15:00", sleepEnd: "2026-03-28T07:00:00", sleepQuality: 7, notes: "" },
  { id: 406, sleepStart: "2026-03-26T22:30:00", sleepEnd: "2026-03-27T06:30:00", sleepQuality: 9, notes: "Excellent" },
  { id: 407, sleepStart: "2026-03-25T23:00:00", sleepEnd: "2026-03-26T07:00:00", sleepQuality: 8, notes: "" },
]

export const sleepChartData = [
  { name: "Mar 26", hours: 8, quality: 8 },
  { name: "Mar 27", hours: 8, quality: 9 },
  { name: "Mar 28", hours: 7.75, quality: 7 },
  { name: "Mar 29", hours: 7.5, quality: 6 },
  { name: "Mar 30", hours: 8, quality: 8 },
  { name: "Mar 31", hours: 7, quality: 7 },
  { name: "Apr 01", hours: 8, quality: 8 },
]

export const healthMetrics = [
  { id: 501, metricType: "Weight", value: 70.5, recordedAt: "2026-04-01T08:00:00" },
  { id: 502, metricType: "Weight", value: 70.8, recordedAt: "2026-03-25T08:00:00" },
  { id: 503, metricType: "Weight", value: 71.2, recordedAt: "2026-03-18T08:00:00" },
  { id: 504, metricType: "Weight", value: 71.5, recordedAt: "2026-03-11T08:00:00" },
  { id: 505, metricType: "Body Fat %", value: 15.2, recordedAt: "2026-04-01T08:00:00" },
  { id: 506, metricType: "Body Fat %", value: 15.5, recordedAt: "2026-03-25T08:00:00" },
  { id: 507, metricType: "BMI", value: 22.9, recordedAt: "2026-04-01T08:00:00" },
  { id: 508, metricType: "Resting Heart Rate", value: 62, recordedAt: "2026-04-01T08:00:00" },
]

export const weightChartData = [
  { name: "Mar 11", weight: 71.5 },
  { name: "Mar 18", weight: 71.2 },
  { name: "Mar 25", weight: 70.8 },
  { name: "Apr 01", weight: 70.5 },
]

// Dashboard summary calculations
export const getSummaryStats = () => {
  const latestBP = bloodPressureLogs[0]
  const latestSleep = sleepLogs[0]
  const weeklyCalories = workouts.reduce((sum, w) => sum + (w.caloriesBurned || 0), 0)
  const weeklyWorkoutMinutes = workouts.reduce((sum, w) => sum + w.durationMin, 0)
  const avgSleepHours = sleepLogs.reduce((sum, s) => {
    const start = new Date(s.sleepStart)
    const end = new Date(s.sleepEnd)
    return sum + (end.getTime() - start.getTime()) / (1000 * 60 * 60)
  }, 0) / sleepLogs.length

  return {
    bloodPressure: {
      systolic: latestBP.systolic,
      diastolic: latestBP.diastolic,
      heartRate: latestBP.heartRate,
    },
    sleep: {
      lastNight: 8,
      quality: latestSleep.sleepQuality,
      avgHours: Math.round(avgSleepHours * 10) / 10,
    },
    workouts: {
      weeklyCalories: Math.round(weeklyCalories),
      weeklyMinutes: weeklyWorkoutMinutes,
      sessionsThisWeek: workouts.length,
    },
    metrics: {
      currentWeight: 70.5,
      bmi: 22.9,
      bodyFat: 15.2,
      restingHeartRate: 62,
    },
  }
}
